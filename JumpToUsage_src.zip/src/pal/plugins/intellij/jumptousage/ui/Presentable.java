package pal.plugins.intellij.jumptousage.ui;

public interface Presentable {
    public void present(PresentationLocation location);
}
